"""Bounded, content-free observation of the installed SDK's generation lifecycle.

The SDK retains parsing, requests, retries and cleanup. A byte chunk is not a
JSON frame. curl_cffi opens its response after its first body callback, so the
response_opened event does not claim a header-only timestamp.
"""
from __future__ import annotations

import asyncio
from collections.abc import Callable
from contextlib import aclosing, contextmanager
from contextvars import ContextVar
from time import monotonic
from typing import Any, Literal

from gemini_webapi import GeminiClient

Phase = Literal[
    "activity_started", "activity_completed", "activity_failed", "activity_cancelled",
    "generation_started", "generation_completed", "generation_failed", "generation_cancelled",
    "request_started", "response_opened", "request_failed", "request_cancelled",
    "first_body_chunk", "candidate_output", "recovery_started", "recovery_completed",
    "recovery_failed", "recovery_cancelled", "stream_exit_started", "stream_exit_completed",
    "stream_exit_failed", "stream_exit_cancelled", "client_close_started", "client_close_completed",
    "client_close_failed", "client_close_cancelled", "cancellation_requested",
]
TaskRole = Literal["generation", "caller", "background_activity", "background_refresh"]
_stream_owner: ContextVar[object | None] = ContextVar("nodia_web_observed_stream", default=None)


class WebGenerationDiagnostics:
    def __init__(self, attempt_id: str, sink: Callable[[dict[str, object]], None] | None = None):
        self.attempt_id, self.sink = attempt_id, sink
        self.started = monotonic()
        self.generation_task: asyncio.Task | None = None
        self.attached = False
        self.last_phase: Phase | None = None
        self.cancelled_at_phase: Phase | None = None
        self.events: list[dict[str, object]] = []
        self.counts = {"byte_chunks": 0, "body_bytes": 0, "candidate_outputs": 0,
                       "activity_calls": 0, "recovery_calls": 0, "client_close_calls": 0}
        self.http_status: int | None = None
        self.sink_errors = 0

    def increment(self, key: str, count: int = 1) -> None:
        self.counts[key] = min(2147483647, self.counts[key] + count)

    def note(self, phase: Phase, role: TaskRole) -> None:
        # Background maintenance must not overwrite where the foreground is
        # blocked. Its lifecycle remains visible in role-labelled events.
        if role in ("generation", "caller"):
            self.last_phase = phase
        if len(self.events) >= 16:
            return
        event: dict[str, object] = {"phase": phase, "task_role": role,
                                    "elapsed_ms": max(0, round((monotonic() - self.started) * 1000))}
        self.events.append(event)
        if self.sink is not None:
            try:
                self.sink({"attempt_id": self.attempt_id, **event})
            except Exception:
                # Diagnostics must not change the SDK's result or cleanup.
                self.sink_errors = min(2147483647, self.sink_errors + 1)

    def cancelling(self) -> None:
        self.cancelled_at_phase = self.last_phase
        self.note("cancellation_requested", "caller")

    def snapshot(self) -> dict[str, object]:
        return {"attached": self.attached, "last_phase": self.last_phase,
                "cancelled_at_phase": self.cancelled_at_phase,
                "elapsed_ms": max(0, round((monotonic() - self.started) * 1000)),
                "http_status": self.http_status, **self.counts,
                "events": [dict(event) for event in self.events], "sink_errors": self.sink_errors}


def _role(client: Any, trace: WebGenerationDiagnostics) -> TaskRole:
    task = asyncio.current_task()
    if task is not None and task is getattr(client, "activity_task", None):
        return "background_activity"
    if task is not None and task is getattr(client, "refresh_task", None):
        return "background_refresh"
    return "generation" if task is trace.generation_task else "caller"


class _Response:
    def __init__(self, response: Any, client: Any, trace: WebGenerationDiagnostics):
        self.response, self.client, self.trace = response, client, trace

    def __getattr__(self, name: str) -> Any:
        return getattr(self.response, name)

    async def aiter_content(self, *args: Any, **kwargs: Any):
        async for chunk in self.response.aiter_content(*args, **kwargs):
            if isinstance(chunk, (bytes, bytearray, memoryview)):
                self.trace.increment("byte_chunks")
                self.trace.increment("body_bytes", len(chunk))
                if self.trace.counts["byte_chunks"] == 1:
                    self.trace.note("first_body_chunk", _role(self.client, self.trace))
            yield chunk


class _StreamContext:
    def __init__(self, context: Any, client: Any, trace: WebGenerationDiagnostics):
        self.context, self.client, self.trace = context, client, trace

    async def __aenter__(self):
        self.trace.note("request_started", _role(self.client, self.trace))
        try:
            response = await self.context.__aenter__()
        except BaseException as error:
            self.trace.note("request_cancelled" if isinstance(error, asyncio.CancelledError) else "request_failed", _role(self.client, self.trace))
            raise
        status = getattr(response, "status_code", None)
        self.trace.http_status = status if type(status) is int and 100 <= status <= 599 else None
        self.trace.note("response_opened", _role(self.client, self.trace))
        return _Response(response, self.client, self.trace)

    async def __aexit__(self, *exception):
        self.trace.note("stream_exit_started", _role(self.client, self.trace))
        try:
            result = await self.context.__aexit__(*exception)
        except BaseException as error:
            self.trace.note("stream_exit_cancelled" if isinstance(error, asyncio.CancelledError) else "stream_exit_failed", _role(self.client, self.trace))
            raise
        self.trace.note("stream_exit_completed", _role(self.client, self.trace))
        return result


class _Transport:
    def __init__(self, session: Any, client: Any, trace: WebGenerationDiagnostics):
        self.session, self.client, self.trace = session, client, trace

    def __getattr__(self, name: str) -> Any:
        return getattr(self.session, name)

    def stream(self, *args: Any, **kwargs: Any):
        return _StreamContext(self.session.stream(*args, **kwargs), self.client, self.trace)


class DiagnosticWebClient(GeminiClient):
    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self._nodia_generation_trace: WebGenerationDiagnostics | None = None

    @property
    def _live_client(self) -> Any:
        session = super()._live_client
        trace = self._nodia_generation_trace
        return _Transport(session, self, trace) if trace is not None and _stream_owner.get() is self else session

    async def _observed(self, phase: str, work):
        trace = self._nodia_generation_trace
        if trace is None:
            return await work()
        role = _role(self, trace)
        trace.increment({"activity": "activity_calls", "recovery": "recovery_calls", "client_close": "client_close_calls"}[phase])
        trace.note(phase + "_started", role)
        try:
            result = await work()
        except BaseException as error:
            trace.note(phase + ("_cancelled" if isinstance(error, asyncio.CancelledError) else "_failed"), role)
            raise
        trace.note(phase + "_completed", role)
        return result

    async def _sync_activity(self):
        return await self._observed("activity", super()._sync_activity)

    async def read_chat(self, *args: Any, **kwargs: Any):
        return await self._observed("recovery", lambda: super(DiagnosticWebClient, self).read_chat(*args, **kwargs))

    async def close(self, *args: Any, **kwargs: Any):
        return await self._observed("client_close", lambda: super(DiagnosticWebClient, self).close(*args, **kwargs))

    async def _generate(self, *args: Any, **kwargs: Any):
        trace = self._nodia_generation_trace
        if trace is not None:
            trace.note("generation_started", _role(self, trace))
        token = _stream_owner.set(self) if trace is not None else None
        try:
            async with aclosing(super()._generate(*args, **kwargs)) as generation:
                async for output in generation:
                    if trace is not None:
                        trace.increment("candidate_outputs")
                        if trace.counts["candidate_outputs"] == 1:
                            trace.note("candidate_output", _role(self, trace))
                    yield output
        except BaseException as error:
            if trace is not None:
                trace.note("generation_cancelled" if isinstance(error, asyncio.CancelledError) else "generation_failed", _role(self, trace))
            raise
        else:
            if trace is not None:
                trace.note("generation_completed", _role(self, trace))
        finally:
            if token is not None:
                _stream_owner.reset(token)


@contextmanager
def observe_generation(client: Any, trace: WebGenerationDiagnostics | None):
    attached = isinstance(client, DiagnosticWebClient) and trace is not None and client._nodia_generation_trace is None
    if attached:
        client._nodia_generation_trace = trace
        trace.attached = True
    try:
        yield
    finally:
        if attached:
            client._nodia_generation_trace = None
            trace.generation_task = None
