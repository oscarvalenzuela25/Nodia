"""Standalone CLI gate: only the structured finish terminator has no I/O."""
import json
import sys
from pathlib import Path


def decide(payload: object) -> bool:
    return (isinstance(payload, dict) and isinstance(payload.get("toolCall"), dict)
            and payload["toolCall"].get("name") == "finish")


def main() -> None:
    allowed = False
    try:
        raw = sys.stdin.buffer.read(65537)
        allowed = len(raw) <= 65536 and decide(json.loads(raw))
        if len(sys.argv) != 2:
            allowed = False
        else:
            with Path(sys.argv[1]).open("a", encoding="utf-8") as receipt:
                receipt.write(json.dumps({"tool": "finish" if allowed else "other", "allowed": allowed}) + "\n")
    except (ValueError, OSError):
        allowed = False
    print(json.dumps({"decision": "allow" if allowed else "deny", "reason": "No runtime tools are published."}))


if __name__ == "__main__":
    main()
