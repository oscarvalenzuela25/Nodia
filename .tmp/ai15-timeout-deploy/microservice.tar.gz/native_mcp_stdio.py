"""Supervisor-owned stdio IPC bridge. No network, app imports, DB or secrets."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import time
from uuid import uuid4

MAX_BYTES = 65536
# Private transport envelopes, not CLI/model quotas. Ordinary RPC/callback limits stay unchanged.
# AI-15 complete read catalog: 67 product reads plus five technical tools.
# This verified transport ceiling is independent from model/provider quotas.
MAX_CATALOG_TOOLS = 72
MAX_CATALOG_BYTES = 131072
MAX_MANIFEST_BYTES = MAX_CATALOG_BYTES + 4096


def pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def bounded_json(raw, max_bytes=MAX_BYTES):
    if len(raw) > max_bytes:
        raise ValueError("Message budget")
    value = json.loads(raw, object_pairs_hook=pairs,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Non-finite JSON")))
    pending = [(value, 0)]
    while pending:
        item, depth = pending.pop()
        if depth > 16:
            raise ValueError("JSON depth")
        if isinstance(item, (dict, list)):
            if len(item) > 128:
                raise ValueError("JSON collection")
            pending.extend((child, depth+1) for child in (item.values() if isinstance(item, dict) else item))
    return value


def atomic(path, value, max_bytes=MAX_BYTES):
    raw = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode()
    if len(raw) > max_bytes:
        raise ValueError("IPC budget")
    temporary = path.with_suffix(".tmp")
    temporary.write_bytes(raw)
    temporary.replace(path)


def read_manifest(path: Path):
    with path.open("rb") as source:
        policy = bounded_json(source.read(MAX_MANIFEST_BYTES + 1), MAX_MANIFEST_BYTES)
    tools = policy.get("tools") if isinstance(policy, dict) else None
    if not isinstance(tools, list) or not 1 <= len(tools) <= MAX_CATALOG_TOOLS:
        raise ValueError("Catalog tool budget")
    names = [tool.get("name") for tool in tools if isinstance(tool, dict)]
    if len(names) != len(tools) or any(not isinstance(name, str) for name in names) or len(set(names)) != len(names):
        raise ValueError("Catalog identity")
    raw = json.dumps(tools, ensure_ascii=False, separators=(",", ":")).encode()
    bounded_json(raw, MAX_CATALOG_BYTES)
    return policy


class StdioBridge:
    def __init__(self, manifest: Path):
        self.policy = read_manifest(manifest)
        self.directory = manifest.parent
        self.tools = {item["name"]: item for item in self.policy["tools"]}
        self.rpc_messages = 0
        self.tool_calls = 0
        self.initialized = False
        self.ready = False
        self.receipts = {}
        self.deadline = time.monotonic() + self.policy["timeout_seconds"]

    def handle(self, request):
        self.rpc_messages += 1
        if self.rpc_messages > self.policy["rpc_budget"]:
            raise ValueError("RPC budget exhausted")
        if isinstance(request, dict) and request.get("method") == "tools/call":
            # Every attempted tool invocation consumes capacity, including denied
            # envelopes and replays that reuse an existing result.
            self.tool_calls += 1
        event = {"kind": "rpc", "rpc_messages": self.rpc_messages,
                 "tool_requests": self.tool_calls}
        target = self.directory / "requests" / (str(self.rpc_messages).zfill(4) + ".json")
        if self.tool_calls > self.policy["tool_budget"]:
            atomic(target,event)
            raise ValueError("Tool budget exhausted")
        identity = request.get("id") if isinstance(request, dict) else None
        def result(value): return {"jsonrpc":"2.0", "id":identity, "result":value}
        def error(code): return {"jsonrpc":"2.0", "id":identity, "error":{"code":code,"message":"Nodia MCP request rejected"}}
        if (not isinstance(request, dict) or request.get("jsonrpc") != "2.0"
                or set(request)-{"jsonrpc","id","method","params"}
                or type(identity) not in (str, int, type(None))):
            atomic(target,event)
            return error(-32600)
        method = request.get("method")
        params = request.get("params",{})
        if method == "initialize":
            atomic(target,event)
            if self.initialized or not isinstance(params,dict) or params.get("protocolVersion") not in ("2025-11-25","2025-06-18","2025-03-26","2024-11-05"):
                return error(-32602)
            self.initialized=True
            return result({"protocolVersion":params["protocolVersion"],"capabilities":{"tools":{}},"serverInfo":{"name":"nodia-runtime","version":"1"}})
        if method == "notifications/initialized" and self.initialized:
            self.ready=True
            atomic(target,event)
            return None
        if method == "notifications/cancelled":
            atomic(target,event)
            return None
        if identity is None:
            atomic(target,event)
            return None
        if not self.ready:
            atomic(target,event)
            return error(-32000)
        if method == "ping":
            atomic(target,event)
            return result({})
        if method == "tools/list":
            atomic(target,event)
            return result({"tools":[{"name":item["name"],"description":item["description"],"inputSchema":item["input_schema"]} for item in self.tools.values()]})
        if method != "tools/call" or not isinstance(params,dict) or set(params)-{"name","arguments","_meta"} or params.get("name") not in self.tools:
            atomic(target,event)
            return error(-32602)
        arguments = params.get("arguments")
        if isinstance(arguments,str) and self.policy["cli_json_string_arguments"]:
            arguments=bounded_json(arguments.encode())
        if not isinstance(arguments,dict):
            atomic(target,event)
            return error(-32602)
        canonical=json.dumps({"name":params["name"],"arguments":arguments},sort_keys=True,separators=(",",":"))
        fingerprint=hashlib.sha256(canonical.encode()).hexdigest()
        receipt_key=json.dumps(identity)
        previous=self.receipts.get(receipt_key)
        if previous is not None:
            atomic(target,event)
            return result(previous[1]) if previous[0]==fingerprint else error(-32600)
        call_id=str(uuid4())
        event.update(kind="tool_request",call_id=call_id,name=params["name"],arguments=arguments)
        atomic(target,event)
        response=self.directory/"responses"/(call_id+".json")
        while not response.exists():
            if time.monotonic()>=self.deadline:
                raise ValueError("Callback deadline")
            time.sleep(0.05)
        value=bounded_json(response.read_bytes())
        if set(value)!={"result"} or not isinstance(value["result"],dict):
            raise ValueError("Invalid callback response")
        payload={"content":[{"type":"text","text":json.dumps(value["result"],ensure_ascii=False)}],"structuredContent":value["result"],"isError":False}
        self.receipts[receipt_key]=(fingerprint,payload)
        return result(payload)


def gate_detail(payload, tools):
    try:
        call=payload["toolCall"]
        name=call["name"]
        if name=="finish":
            allowed=isinstance(call.get("args"),dict)
            return "finish",allowed,"allowed_finish" if allowed else "finish_arguments","finish"
        if name=="call_mcp_tool":
            args=call["args"]
            if not isinstance(args,dict): return "other",False,"dispatcher_envelope","dispatcher"
            if set(args)-{"ServerName","ToolName","Arguments","toolAction","toolSummary"}:return "other",False,"dispatcher_extra_fields","dispatcher"
            if args.get("ServerName")!="nodia_runtime":return "other",False,"foreign_server","dispatcher"
            if args.get("ToolName") not in tools:return "other",False,"unregistered_tool","dispatcher"
            value=args.get("Arguments")
            if not isinstance(value,(str,dict)):return "other",False,"arguments_type","dispatcher"
            try:
                raw=value.encode() if isinstance(value,str) else json.dumps(value,ensure_ascii=False,allow_nan=False).encode()
                arguments=bounded_json(raw)
            except (ValueError,UnicodeError,TypeError,OverflowError,RecursionError):return "other",False,"arguments_json","dispatcher"
            if not isinstance(arguments,dict):return "other",False,"arguments_shape","dispatcher"
            return args["ToolName"],True,"allowed_registered","dispatcher"
        aliases={alias:tool for tool in tools for alias in (tool,"mcp_nodia_runtime_"+tool,"mcp_nodia_runtime__"+tool)}
        if name not in aliases:return "other",False,"unregistered_native","other"
        if not isinstance(call.get("args"),dict):return "other",False,"arguments_type","registered"
        return aliases[name],True,"allowed_registered","registered"
    except (ValueError,KeyError,TypeError,AttributeError):
        return "other",False,"payload_shape","other"


def gate(payload, tools):
    name,allowed,_,_=gate_detail(payload,tools)
    return name,allowed


def main():
    # JSON-RPC is UTF-8 on every host; Windows redirected stdout otherwise uses
    # the locale codepage and corrupts non-ASCII catalog descriptions.
    sys.stdout.reconfigure(encoding="utf-8")
    if len(sys.argv)==4 and sys.argv[1]=="gate":
        allowed=False
        name="other"
        category="invalid_json"
        call_kind="other"
        try:
            manifest=read_manifest(Path(sys.argv[2]))
            name,allowed,category,call_kind=gate_detail(bounded_json(sys.stdin.buffer.read(MAX_BYTES+1)),{tool["name"] for tool in manifest["tools"]})
            with Path(sys.argv[3]).open("a",encoding="utf-8") as output:
                output.write(json.dumps({"tool":name,"allowed":allowed})+"\n")
        except (ValueError,OSError): pass
        try:
            # Structural categories only. The proof receipt keeps its exact two-field contract.
            with Path(sys.argv[3]).with_name("gate-diagnostic.jsonl").open("a",encoding="utf-8") as output:
                output.write(json.dumps({"category":category,"call_kind":call_kind})+"\n")
        except OSError:pass
        print(json.dumps({"decision":"allow" if allowed else "deny","reason":"Only registered Nodia MCP calls and finish are allowed."}))
        return 0
    if len(sys.argv)!=2: return 2
    try:
        bridge=StdioBridge(Path(sys.argv[1]))
        while raw:=sys.stdin.buffer.readline(MAX_BYTES+1):
            reply=bridge.handle(bounded_json(raw))
            if reply is not None: print(json.dumps(reply,ensure_ascii=False),flush=True)
        return 0
    except (ValueError,OSError,KeyError,TypeError):
        return 2


if __name__=="__main__":
    sys.exit(main())
