"""Contract/gating/file lifetime regressions, entirely synthetic."""
import base64
import asyncio
import hashlib
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock
from uuid import uuid4

from attachment_inspector import AttachmentInspector, AttachmentInspection
from native_attachments import NativeAttachment, materialize, attachment_digest, probe_answer_hash
from nodia_ai_chat import ChatAdapter, ChatRequest, AttachmentProbeRequest, parse_reply
from profile_admission import ProfileAdmission
from service_errors import ServiceError
from nodia_ai_tool_gate import file_decision
from native_mcp_stdio import gate_detail


def file_input(content=b"synthetic file"):
    return {"kind": "image", "media_type": "image/png", "sha256": hashlib.sha256(content).hexdigest(), "content_base64": base64.b64encode(content).decode()}


class NativeAttachmentTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.directory = self.enterContext(tempfile.TemporaryDirectory())
        self.root = Path(self.directory)
        self.inspector = AttachmentInspector(self.root / "files")
        self.inspector.decode = AsyncMock(return_value=AttachmentInspection(media_type="image/png", page_count=None, duration_seconds=None))
        self.profiles = ProfileAdmission(self.root / "web", None, self.root / "state")
        self.web = SimpleNamespace(is_initialized=True, client=object(), session_generation="a" * 32,
            discovered_models=lambda: [SimpleNamespace(model_id="fixture-model")], _reasoning_profiles={},
            _reasoning_profile_invalid=False, supported_options=lambda: {"thinking_levels_by_model": {}},
            init_client=AsyncMock(), _generate_content=AsyncMock(return_value=SimpleNamespace(text='{"kind":"answer","text":"synthetic marker"}')),
            _persist_live_cookies=Mock())
        self.adapter = ChatAdapter(self.web, SimpleNamespace(), self.profiles, self.inspector)

    def request(self, probe=False, **changes):
        value = {"attempt_id": str(uuid4()), "model_id": "fixture-model", "effort_id": None,
            "canonical_prompt": "Do not copy expected answer from here", "resource_key": self.profiles.identity("web"),
            "session_generation": "a" * 32, "configuration_generation": "b" * 64, "timeout_seconds": 5,
            "attachments": [file_input()], **changes}
        if probe:
            value["expected_answer_sha256"] = hashlib.sha256(b"synthetic marker").hexdigest()
        return (AttachmentProbeRequest if probe else ChatRequest).model_validate(value)

    async def test_unverified_mode_kind_never_decodes_or_dispatches(self):
        with self.assertRaises(ServiceError) as raised:
            await self.adapter.execute("web", self.request())
        self.assertEqual(raised.exception.code, "attachment_adapter_unverified")
        self.inspector.decode.assert_not_awaited()
        self.web._generate_content.assert_not_awaited()

    async def test_hash_mismatch_is_before_dispatch_and_files_are_cleaned(self):
        item = NativeAttachment.model_validate({**file_input(), "sha256": "0" * 64})
        with self.assertRaises(ServiceError):
            async with materialize([item], self.inspector):
                self.fail("Invalid hash reached inference")
        self.inspector.decode.assert_not_awaited()
        self.assertEqual(list(self.inspector.directory.iterdir()), [])

    async def test_shared_native_bytes_fail_fast_and_release_after_cancellation(self):
        item = NativeAttachment.model_validate(file_input())
        with self.inspector.reserve_native_bytes(40 * 1024 * 1024):
            with self.assertRaises(ServiceError) as raised:
                async with materialize([item], self.inspector):
                    self.fail("Saturated native staging admitted")
            self.assertEqual(raised.exception.code, "service_busy")
            self.inspector.decode.assert_not_awaited()
            self.assertEqual(list(self.inspector.directory.iterdir()), [])
        self.assertEqual(self.inspector.native_bytes, 0)
        with self.assertRaises(asyncio.CancelledError):
            async with materialize([item], self.inspector):
                self.assertEqual(self.inspector.native_bytes, len(b"synthetic file"))
                raise asyncio.CancelledError()
        self.assertEqual(self.inspector.native_bytes, 0)
        self.assertEqual(list(self.inspector.directory.iterdir()), [])

    async def test_noncanonical_base64_and_kind_mismatch_are_rejected(self):
        for changes in ({"content_base64": "Zg==AAAA"}, {"media_type": "image/jpeg"}):
            item = NativeAttachment.model_validate({**file_input(), **changes})
            with self.assertRaises(ServiceError):
                async with materialize([item], self.inspector):
                    self.fail("Invalid file reached inference")
        self.assertEqual(list(self.inspector.directory.iterdir()), [])

    async def test_probe_verifies_semantics_then_exact_native_channel_works(self):
        probe = self.request(probe=True)
        seen = []
        async def generate(prompt, **options):
            self.assertNotIn(probe.canonical_prompt, prompt)
            self.assertNotIn(probe.expected_answer_sha256, prompt)
            path = options["files"][0]
            self.assertTrue(path.is_file())
            self.assertEqual(path.read_bytes(), b"synthetic file")
            seen.append(path)
            return SimpleNamespace(text='{"kind":"answer","text":"synthetic marker"}')
        self.web._generate_content.side_effect = generate
        await self.adapter.probe_attachments(probe)
        self.assertTrue(self.adapter.attachment_proofs.supports("web", probe, "image"))
        self.assertFalse(seen[0].exists())
        proof = self.adapter.ledger.read(probe.attempt_id)
        self.assertEqual(proof.input_digest, hashlib.sha256((attachment_digest(probe.attachments) + ":nodia-ai-native-attachments/2:literal").encode()).hexdigest())
        request = self.request()
        self.web._generate_content.side_effect = None
        await self.adapter.execute("web", request)
        self.assertEqual(self.web._generate_content.await_count, 2)
        self.assertEqual(list(self.inspector.directory.iterdir()), [])
        for changes in ({"configuration_generation": "c" * 64}, {"model_id": "other-model"}, {"effort_id": "high"}):
            with self.assertRaises(ServiceError):
                await self.adapter.execute("web", self.request(**changes))

    async def test_wrong_canary_answer_keeps_receipt_but_never_enables_modality(self):
        probe = self.request(probe=True)
        self.web._generate_content.return_value = SimpleNamespace(text='{"kind":"answer","text":"wrong"}')
        await self.adapter.probe_attachments(probe)
        self.assertFalse(self.adapter.attachment_proofs.supports("web", probe, "image"))
        self.assertEqual(self.adapter.ledger.read(probe.attempt_id).state, "completed")

    async def test_generation_failure_cleans_files_and_preserves_unknown_no_retry(self):
        probe = self.request(probe=True)
        self.web._generate_content.side_effect = TimeoutError()
        with self.assertRaises(ServiceError):
            await self.adapter.probe_attachments(probe)
        self.assertEqual(self.web._generate_content.await_count, 1)
        self.assertEqual(list(self.inspector.directory.iterdir()), [])
        self.assertEqual(self.adapter.ledger.read(probe.attempt_id).state, "abandoned_unknown")
        self.assertFalse(self.adapter.attachment_proofs.verified)

    def test_cli_hooks_allow_only_exact_generated_files_and_no_business_privilege(self):
        document = self.root / "attachment.png"
        document.write_bytes(b"synthetic")
        other = self.root / "unrelated-secret.txt"
        other.write_text("synthetic secret")
        allowed = {"toolCall": {"name": "view_file", "args": {"AbsolutePath": str(document.resolve())}}}
        self.assertEqual(file_decision(allowed, [str(document.resolve())]), ("attachment_0", True))
        self.assertEqual(gate_detail(allowed, {"fixture_read"}, [str(document.resolve())])[:2], ("attachment_0", True))
        for payload in ({"toolCall": {"name": "view_file", "args": {"AbsolutePath": str(other.resolve())}}}, {"toolCall": {"name": "run_command", "args": {"CommandLine": "synthetic"}}}, {"toolCall": {"name": "read_url", "args": {"Url": "https://invalid.example"}}}):
            self.assertFalse(file_decision(payload, [str(document.resolve())])[1])
            self.assertFalse(gate_detail(payload, {"fixture_read"}, [str(document.resolve())])[1])
        # A document-read grant never adds MCP operation names or confirmation.
        self.assertFalse(file_decision({"toolCall": {"name": "call_mcp_tool", "args": {}}}, [str(document.resolve())])[1])
        self.assertFalse(gate_detail({"toolCall": {"name": "confirm", "args": {}}}, {"fixture_read"}, [str(document.resolve())])[1])

    def test_json_presentation_fences_remain_strict_structured_answers(self):
        for prefix, newline in (("json", "\n"), ("JSON", "\r\n"), ("", "\n")):
            raw = '```'+prefix+newline+'{"kind":"answer","text":"synthetic"}'+newline+'```'
            self.assertEqual(parse_reply(raw, "web").text, "synthetic")
        for raw in ('synthetic', 'prefix {"kind":"answer","text":"synthetic"}', '```python\n{"kind":"answer","text":"synthetic"}\n```', '{"kind":"answer","text":"synthetic","execute":true}'):
            with self.assertRaises(ValueError):
                parse_reply(raw, "web")

    def test_speech_probe_normalization_preserves_every_word_and_number(self):
        expected = probe_answer_hash("The purple lantern is seven.", "speech_words_v1")
        self.assertEqual(expected, probe_answer_hash("THE  purple lantern is seven!", "speech_words_v1"))
        self.assertNotEqual(expected, probe_answer_hash("The purple lantern is six.", "speech_words_v1"))
        self.assertNotEqual(expected, probe_answer_hash("The lantern is seven.", "speech_words_v1"))
        self.assertNotEqual(probe_answer_hash("seven 12", "speech_words_v1"), probe_answer_hash("seven 13", "speech_words_v1"))


if __name__ == "__main__":
    unittest.main()
