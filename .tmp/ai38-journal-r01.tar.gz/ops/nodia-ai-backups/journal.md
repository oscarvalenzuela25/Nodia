# Journal externo de borrados de NodiaAI

Estado de este runbook: implementación candidata, adopción en VM y aceptación operativa sujetas a su recibo de AI-38. Ejecutar el procedimiento no aprueba documentos ni cierra otros gates. La decisión y sus alternativas están en [ADR-070](../../docs/architecture/decisions/ADR-070-external-deletion-journal-and-encrypted-backups.md); el formato de cifrado de backups y las unidades están en [README](README.md).

## Destino y custodia

El journal y el catálogo comparten el objeto privado `nodia-ai-recovery/<deployment_id>/state.bin` de R2. No depende de Redis ni de tablas del dump. AES-256-GCM autentica bytes y AAD de era/deployment; el ETag sólo identifica la versión CAS, no sustituye el digest o tag. Reservar ese namespace al escritor autorizado y conservar fuera de los backups la configuración necesaria para leer el head actual. No permitir que un restore de VM reemplace el objeto externo por una copia antigua.

Provisionar un archivo JSON regular privado, de modo 0600 en Linux, con exactamente estos campos: `schema_version:1`, `deployment_id`, `era_id`, `endpoint`, `bucket`, `access_key_id`, `secret_access_key`, `journal_encryption_key`. `deployment_id` es un identificador operativo estable; `era_id`, un UUID v4 nuevo. `endpoint` requiere HTTPS. `journal_encryption_key` es una clave aleatoria de 32 bytes codificada en base64 canónico. No colocar valores reales en repositorio, variables públicas, argumentos de comandos, logs o formularios. Los CLI reciben sólo el path del archivo.

API y worker deben compartir `NODIA_AI_RECOVERY_CONFIG_FILE` con el mismo path absoluto y arrancar desde el paquete cuya integración fue comprobada. Si existe la variable y el archivo es inválido, el arranque falla; un fallo remoto durante el borrado falla cerrado. Sin la variable se usa compatibilidad legacy NOOP: no afirmar protección de backups en ese modo. La cuarentena offline instancia el NOOP explícitamente y no accede a R2 durante su preparación SQL.

La clave simétrica del journal y la RSA de backups son diferentes. La VM conserva la simétrica privada y sólo la RSA **pública**. La RSA privada se custodia en Windows fuera de la VM y de sus copias; conservar claves anteriores mientras existan copias que las requieran. Verificar recuperación real antes de aceptar continuidad. Cambiar era, clave o destino no es un mecanismo para saltarse pendientes; requiere preservar cobertura y registrar una transición controlada.

## Inicialización de una era

1. Verificar build, pruebas, paquete efectivo y configuración privada. Inventariar qué copias anteriores quedan fuera del catálogo. Comprobar UTC del entorno; no deducir tiempos de cobertura desde el reloj de otro equipo.
2. Detener `nodia-api` y `nodia-ai-worker`. Confirmar ambos inactivos y PID 0. El CLI comprueba esos dos escritores; el operador debe impedir otros escritores directos que el CLI no puede descubrir.
3. Desde el paquete que se adoptará, ejecutar `node scripts/nodia-ai-journal.mjs bootstrap /ruta/privada/recovery.json`. Sólo crea un estado ausente con `If-None-Match: *`; un estado existente no se reinicializa. Conservar la respuesta segura de cobertura, sin configuración o contenido.
4. Verificar `node scripts/nodia-ai-journal.mjs status /ruta/privada/recovery.json`. La cobertura empieza en la inicialización real; no incluye el periodo anterior. No fabricar eventos retrospectivos desde los 29 dumps históricos, un snapshot o logs parciales.
5. Arrancar los escritores con el paquete/configuración comprobados y observar su integración. Sólo después iniciar el scheduler de backups y producir una primera captura verificable. La adopción y su aceptación requieren evidencia aparte; bootstrap por sí solo no las demuestra.

El transporte tiene un deadline de 5 s para estado/CAS y hasta tres intentos sólo ante conflictos de precondición definidos. Los callbacks de CAS son puros. Un resultado incierto no provoca un replay de PUT; se intenta comprobar el contenido exacto mediante una lectura. No convertir errores, estado corrupto o journal ausente en una lista vacía válida.

## Qué se registra y cuándo

Los tres recursos admitidos son chats (`conversation_id` y generaciones), adjuntos individuales (`conversation_id`, `attachment_id` y una generación) y preferencias (`preference_id`). Los eventos no contienen texto, archivos, valores recordados, usuario ni keys de almacenamiento. El productor protege la purga de chats, el retiro/limpieza de adjuntos y el borrado confirmado de preferencias.

La fase SQL de preparación captura y verifica identidades; se liberan locks antes de llamar a R2. La segunda fase SQL revalida objetivo, autoridad, revisión, lease y generaciones pertinentes antes del efecto. El journal empieza con `confirmed_at:null`; sólo se confirma fuera de SQL tras un commit demostrado. La confirmación exacta del usuario para operaciones de negocio no cambia. Los adjuntos retirados conservan sus testigos de limpieza nativa hasta resolver el objeto.

Un fallo o timeout al registrar impide el DELETE local protegido. Si R2 confirmó una intención pero SQL falla o su resultado es incierto, conservar el evento pendiente. Si SQL ya completó el efecto y falla la confirmación externa, conservar su recibo y el pendiente; no reportar un efecto fallido que invite a repetirlo. Estos pendientes bloquean nuevas copias para evitar capturar contenido que una intención anterior podría borrar después.

## Inspección y conciliación

Usar `node scripts/nodia-ai-journal.mjs status /ruta/privada/recovery.json` para observar cobertura, secuencia, entradas, pendientes y copias expiradas. La salida no contiene credenciales ni payloads y mantiene `release_authorized:false`. El estado está acotado a 8 MiB, 10.000 eventos y 1.024 copias; acercarse al límite requiere seguimiento, no borrar testigos arbitrariamente.

Para conciliar efectos locales ya terminados, ejecutar `node scripts/nodia-ai-journal.mjs reconcile /ruta/privada/recovery.json /ruta/privada/backups.json`. Ambas configuraciones deben señalar el mismo recovery. El CLI consulta en una transacción SQL de sólo lectura un máximo de 100 pendientes y confirma externamente únicamente IDs ausentes de su tabla de origen. Repetir por lotes si quedan más. No ejecuta borrados SQL, no envía herramientas ni resuelve un ID todavía presente. Ausencia SQL de un adjunto no prueba por sí sola que R2 ya se haya limpiado; sus trabajos de eliminación y el inventario de objetos conservan esa responsabilidad.

No reemplazar `state.bin`, marcar a mano `confirmed_at` o borrar el pendiente para desbloquear backups. Primero acreditar el resultado actual; si continúa incierto, conservar el testigo y el bloqueo. Los fallos de timers, capacidad o CAS y la antigüedad de pendientes son errores operativos observables.

## Rotación de copias y GC del journal

El runner reserva la identidad de copia antes de capturar y exige un checkpoint sin borrados pendientes. Cada backup cifra el dump en streaming con un DEK propio y envuelve ese DEK con RSA-OAEP-SHA256. El spool local contiene únicamente ciphertext. Antes de PUT se guarda su tamaño/digest esperado en el catálogo externo; luego un único PUT condicional y HEAD/GET de su key exacta acreditan ready. El lock local y un único scheduler por destino excluyen runners legítimos concurrentes; no autorizan varios hosts escritores.

Las copias expiran lógicamente a siete días. La rotación del [README](README.md) trabaja sólo con sus entradas registradas, marca deleting y conserva el testigo hasta ausencia verificada. El timer propone cada cinco minutos; caídas de VM/red/R2 pueden exceder ese intervalo y el objetivo de 24 h. Las copias desconocidas, versiones/multipart ajenos y snapshots del hipervisor no quedan inventariados por este runner.

Un pending con receipt durable y 404 permanece indefinidamente conciliable: la subida pudo haberse emitido y aparecer después. No repetir su PUT, no crear otro snapshot con esa identidad ni considerar ese 404 prueba de cancelación remota. Una reserva sin receipt durable no pudo alcanzar el PUT y admite su camino de conciliación específico. Pasar siete días vuelve inadmisible la copia, sin autorizar descartar metadata de una escritura incierta.

R2 rechazó PUT/GET con precondiciones incorrectas, pero **ignoró DELETE If-Match incorrecto** en el [probe real](../../docs/evidence/nodia-ai-ai38-journal-r2-probe-r01.json). El borrado del artefacto depende de key UUID exclusiva e inmutable, único PUT `If-None-Match: *`, prohibición de sobrescritura/replay y verificación positiva HEAD/GET de identidad, tamaño y digest antes del DELETE. Un ETag no vuelve atómico ese borrado. VersionId o digest distintos fallan cerrados; no barrer prefijos ni buckets. La [documentación primaria de R2](https://developers.cloudflare.com/r2/api/s3/api/) describe las condiciones de PUT/HEAD/GET; su existencia no demuestra soporte equivalente en DELETE.

Después de una rotación correcta, el CLI ejecuta prune. El GC sólo retira el prefijo contiguo confirmado con ocho días desde `confirmed_at` y sin copias registradas capturadas antes de esa confirmación. Cualquier pendiente o copia aún registrada impide su descarte. El octavo día es margen de metadata para el horizonte de siete días de las copias, no extensión de retención de contenido. Las copias antiguas fuera del catálogo siguen requiriendo inventario y disposición explícitos; no se migran ni destruyen automáticamente.

## Exportación y restore en cuarentena

1. Detener los escritores y registrar `quarantined_at` en UTC del entorno. Usar una copia ready aún admisible, su identidad/digest del catálogo y la clave RSA privada externa para verificar y descifrar únicamente a cuarentena privada. Ninguna salida previa a verificar el tag GCM es válida.
2. Ejecutar `node scripts/nodia-ai-journal.mjs export /ruta/privada/recovery.json <backup_uuid> <quarantined_at_ISO> /ruta/privada/nueva-exportacion`. El CLI exige escritores detenidos, emite una barrera CAS posterior a ese instante y crea archivos nuevos privados `manifest.json`, `external-head.json` y `metadata.json`; no sobrescribe una exportación previa.
3. Usar el head recién obtenido del journal externo, jamás uno recuperado del backup. El manifiesto versión 2 incluye todos los eventos retenidos, también pendientes y anteriores a la captura: la intención puede preceder al snapshot y el DELETE local ocurrir después. No filtrar sólo por fecha de captura o secuencia posterior al checkpoint del backup.
4. Restaurar PostgreSQL aislado y ejecutar [prepare-nodia-ai-restore.mjs](../../nodia-server/scripts/prepare-nodia-ai-restore.mjs) en `NODIA_AI_OPERATION_MODE=quarantine`, con target `nodia_restore_*` y los cuatro archivos privados que exige el CLI. La preparación invalida confirmaciones y aplica los borrados por recurso sin acceso remoto. El consumidor acepta manifiestos históricos versión 1 de chats; esa compatibilidad no crea cobertura de adjuntos/preferencias ausente en el productor antiguo.
5. Conciliar dominio, testigos y runtimes actuales antes de cualquier apertura normal. `prepared:true` mantiene `release_authorized:false`. No arrancar un worker normal contra la copia para que reenvíe trabajos históricos o use confirmaciones viejas. Si falta journal/head/cobertura, conservar cuarentena.

## Evidencia necesaria para aceptar el entorno

Conservar hashes del paquete y configuración sin secretos, inicio real de era, prueba de cada tipo de borrado, ausencia de red bajo locks, fallo externo cerrado, conciliación postcommit, captura/PUT/digest, descifrado y restore PostgreSQL aislado, caducidad/limpieza y reinicio del scheduler. Separar esas pruebas de la cobertura histórica y de la limpieza física interna del proveedor. El runbook no acredita por sí mismo continuidad, rotación global de las 29 copias previas ni los objetivos de 7 d/24 h durante una caída.
