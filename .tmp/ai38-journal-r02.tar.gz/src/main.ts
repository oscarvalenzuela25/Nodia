import cookieParser from 'cookie-parser';
import { createNodiaAiConversationBodyParser } from './nodia-ai-conversation/nodia-ai-conversation-body-parser.js';
import { NODIA_AI_RUNTIME_POLICY, type NodiaAiRuntimePolicy } from './nodia-ai-runtime/config/runtime-policy.js';
import { providerImportBodyParser } from './provider/provider-import-body-parser.js';
import { rentalBodyParser } from './rental-common/rental-body-parser.js';
import { readAuthConfig } from './auth/auth.config.js';
import { NestFactory } from '@nestjs/core';
import { Logger } from '@nestjs/common';
import { RentalValidationPipe } from './rental-common/rental-validation.pipe.js';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { NestExpressApplication } from '@nestjs/platform-express';
import qs from 'qs';
import { AppModule } from './app.module.js';
import { envs } from './config/envs.config.js';
import { AllExceptionsFilter } from './common/filters/all-exceptions.filter.js';
import { LoggingInterceptor } from './common/interceptors/logging.interceptor.js';
import { AssertNodiaAiOperationModeUseCase } from './nodia-ai-runtime/use-case/assert-nodia-ai-operation-mode.use-case.js';

async function bootstrap() {
  new AssertNodiaAiOperationModeUseCase().execute(process.env);
  if (process.env.NODE_ENV === 'production') {
    if (!/^[0-9a-fA-F]{64}$/.test(process.env.AI_SECRET_MASTER_KEY || '')) {
      throw new Error(
        'AI_SECRET_MASTER_KEY must contain 64 hexadecimal characters',
      );
    }
    if (!/^[0-9a-fA-F]{64}$/.test(process.env.GEMINI_SERVICE_TOKEN || '')) {
      throw new Error(
        'GEMINI_SERVICE_TOKEN must contain 64 hexadecimal characters',
      );
    }
  }
  const logger = new Logger('Bootstrap');
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  app.enableShutdownHooks();
  app.set('trust proxy', envs.RATE_LIMIT.trustedProxies);

  // Parse nested query strings (Ransack queries like q[name_in][0]=Oscar, q[is_active_eq]=true)
  app.set('query parser', (str: string) =>
    qs.parse(str, {
      allowDots: true,
      comma: true,
    }),
  );

  // Set global prefix for all routes
  app.setGlobalPrefix('/api/v1');
  // Installed before Nest's default parser; rental payloads are bounded before parsing.
  app.use('/api/v1/rental', rentalBodyParser);
  app.use(['/api/v1/providers/import', '/api/v1/provider/import'], providerImportBodyParser);
  app.use('/api/v1/nodia-ai', createNodiaAiConversationBodyParser(app.get<NodiaAiRuntimePolicy>(NODIA_AI_RUNTIME_POLICY).admission.http_json_bytes));

  const authConfig = readAuthConfig(process.env);
  app.use(cookieParser());
  app.enableCors({
    origin: authConfig.origins,
    credentials: true,
    exposedHeaders: ['Retry-After'],
  });

  // Enable global validation pipe
  app.useGlobalPipes(
    new RentalValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  // Global exception filter
  app.useGlobalFilters(new AllExceptionsFilter());

  // Global request logging interceptor
  app.useGlobalInterceptors(new LoggingInterceptor());

  if (process.env.NODE_ENV !== 'production') {
    const config = new DocumentBuilder()
      .setTitle('Documentation API')
      .setDescription('API documentation')
      .setVersion('1.0')
      .addBearerAuth()
      .build();
    const documentFactory = () => SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('/api/documentation', app, documentFactory);
  }

  await app.listen(envs.PORT);

  logger.log(`🚀 Application running on: http://localhost:${envs.PORT}/api/v1`);
  if (process.env.NODE_ENV !== 'production') {
    logger.log(
      `📚 Swagger documentation: http://localhost:${envs.PORT}/api/documentation`,
    );
  }
}
await bootstrap();
