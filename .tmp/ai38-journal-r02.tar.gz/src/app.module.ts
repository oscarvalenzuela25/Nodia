import { AuthModule } from './auth/auth.module.js';
import { Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { AppController } from './app.controller.js';
import { AppService } from './app.service.js';
import { postgresConfig } from './config/db.config.js';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserModule } from './user/user.module.js';
import { RoleModule } from './role/role.module.js';
import { ActionModule } from './action/action.module.js';
import { ModuleModule } from './module/module.module.js';
import { ModuleGroupModule } from './module-group/module-group.module.js';
import { TranslationModule } from './translation/translation.module.js';
import { AuthorizationModule } from './authorization/authorization.module.js';
import { AiProviderModule } from './ai-provider/ai-provider.module.js';
import { BusinessModule } from './business/business.module.js';
import { BusinessActionModule } from './business-action/business-action.module.js';
import { ProviderModule } from './provider/provider.module.js';
import { ProviderContactModule } from './provider-contact/provider-contact.module.js';
import { InvoiceModule } from './invoice/invoice.module.js';
import { ProductModule } from './product/product.module.js';
import { RedisModule } from './common/redis/redis.module.js';
import { RateLimitModule } from './rate-limit/rate-limit.module.js';
import { RateLimitGuard } from './rate-limit/rate-limit.guard.js';
import { UserRateLimitGuard } from './rate-limit/user-rate-limit.guard.js';
import { AuthGuard } from './auth/auth.guard.js';
import { ActionPermissionGuard } from './authorization/action-permission.guard.js';
import { FinanceCategoryModule } from './finance-category/finance-category.module.js';
import { FinanceCategoryGroupModule } from './finance-category-group/finance-category-group.module.js';
import { FinanceObligationModule } from './finance-obligation/finance-obligation.module.js';
import { FinanceMovementModule } from './finance-movement/finance-movement.module.js';
import { FinanceOverviewModule } from './finance-overview/finance-overview.module.js';
import { RentalModule } from './rental-common/rental.module.js';
import { NodiaAiModule } from './nodia-ai/nodia-ai.module.js';
import { NodiaAiPreferenceModule } from './nodia-ai-preference/nodia-ai-preference.module.js';

@Module({
  imports: [
    TypeOrmModule.forRoot(postgresConfig),
    RedisModule,
    RateLimitModule,
    AuthModule,
    UserModule,
    RoleModule,
    ActionModule,
    BusinessActionModule,
    BusinessModule,
    ProviderModule,
    ProviderContactModule,
    InvoiceModule,
    ProductModule,
    ModuleGroupModule,
    ModuleModule,
    TranslationModule,
    AuthorizationModule,
    AiProviderModule,
    FinanceCategoryModule,
    FinanceCategoryGroupModule,
    FinanceObligationModule,
    FinanceMovementModule,
    FinanceOverviewModule,
    RentalModule,
    NodiaAiModule,
    NodiaAiPreferenceModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    // Keep this order explicit: protect authentication work by IP, verify the
    // principal, then consume the verified user's quota across sessions/IPs.
    { provide: APP_GUARD, useExisting: RateLimitGuard },
    { provide: APP_GUARD, useExisting: AuthGuard },
    { provide: APP_GUARD, useExisting: UserRateLimitGuard },
    { provide: APP_GUARD, useExisting: ActionPermissionGuard },
  ],
})
export class AppModule {}
