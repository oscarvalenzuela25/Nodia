import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository, type EntityManager } from 'typeorm';
import { lockAuthority } from '../authorization/authority-transaction.js';
import { Business } from './entities/business.entity.js';
import { BusinessCollaborator } from './entities/business-collaborator.entity.js';
import { BusinessAction } from '../business-action/entities/business-action.entity.js';
import { Product } from '../product/entities/product.entity.js';
import { Provider } from '../provider/entities/provider.entity.js';
import { UserRole } from '../user/entities/user-role.entity.js';
import { CreateBusinessDto } from './dto/create-business.dto.js';
import { UpdateBusinessDto } from './dto/update-business.dto.js';
import { GetBusinessesDto } from './dto/get-businesses.dto.js';
import { AssignCollaboratorsDto } from './dto/assign-collaborators.dto.js';
import { applyRansack, validateRansackEnvelope } from '../common/utils/ransack-query.builder.js';
import { RANSACK_POLICIES } from '../common/utils/ransack-query.policies.js';
import { GetBusinessesResponse } from './types/business.types.js';
import { TranslationService } from '../translation/translation.service.js';

@Injectable()
export class BusinessService {
  constructor(
    @InjectRepository(Business)
    private readonly businessRepository: Repository<Business>,
    @InjectRepository(BusinessCollaborator)
    private readonly collaboratorRepository: Repository<BusinessCollaborator>,
    @InjectRepository(BusinessAction)
    private readonly businessActionRepository: Repository<BusinessAction>,
    @InjectRepository(Product)
    private readonly productRepository: Repository<Product>,
    @InjectRepository(Provider)
    private readonly providerRepository: Repository<Provider>,
    @InjectRepository(UserRole)
    private readonly userRoleRepository: Repository<UserRole>,
    private readonly translationService: TranslationService,
  ) {}

  private async isSuperAdmin(userId?: string, manager?: EntityManager): Promise<boolean> {
    if (!userId) return false;
    const count = await (manager?.getRepository(UserRole) ?? this.userRoleRepository)
      .createQueryBuilder('ur')
      .innerJoin('ur.role', 'r')
      .where('ur.user_id = :userId', { userId: String(userId) })
      .andWhere('ur.is_active = true')
      .andWhere('r.is_active = true')
      .andWhere('r.key = :key', { key: 'super_admin' })
      .getCount();
    return count > 0;
  }

  async findMyBusinesses(
    userId: string,
    { page = 1, limit = 10, all = false, includes = true, all_businesses = false, q }: GetBusinessesDto,
    includeSummary = true,
  ): Promise<GetBusinessesResponse> {
    const isSuper = await this.isSuperAdmin(userId);
    const qb = this.businessRepository.createQueryBuilder('business');
    validateRansackEnvelope(q);

    // Super admin consultando todos los negocios si all_businesses es true
    if (isSuper && all_businesses) {
      // Sin restricción de pertenencia para super admin
    } else {
      // Negocios donde el usuario es owner o colaborador activo
      qb.where(
        '(business.owner_id = :userId OR business.id IN (SELECT bc.business_id FROM business_collaborators bc WHERE bc.user_id = :userId AND bc.is_active = true))',
        { userId: String(userId) },
      );
    }

    if (includes) {
      qb.leftJoinAndSelect('business.owner', 'owner');
    }

    applyRansack(qb, q, 'business', RANSACK_POLICIES.business);
    if (!/^id(?:\s|$)/i.test(q?.s?.trim() ?? '')) qb.addOrderBy('business.id', 'ASC');

    const formatBusinesses = async (businesses: Business[]): Promise<Business[]> => {
      if (businesses.length === 0) return [];
      // Scoped readers need the same membership rules without unbounded secondary summaries.
      if (!includeSummary) return this.translationService.attachTranslations('businesses', businesses);

      const businessIds = businesses.map((b) => b.id);

      // Ejecutar consultas de agregación en paralelo
      const [
        myCollaborations,
        collabCountsRaw,
        productsCountsRaw,
        providersWithCountsRaw,
        translated,
      ] = await Promise.all([
        // 1. Datos de colaboración del usuario actual
        this.collaboratorRepository.find({
          where: {
            business_id: In(businessIds),
            user_id: String(userId),
            is_active: true,
          },
        }),
        // 2. Conteo de colaboradores por negocio
        this.collaboratorRepository
          .createQueryBuilder('bc')
          .select('bc.business_id', 'business_id')
          .addSelect('COUNT(bc.id)', 'count')
          .where('bc.business_id IN (:...businessIds)', { businessIds })
          .andWhere('bc.is_active = true')
          .groupBy('bc.business_id')
          .getRawMany(),
        // 3. Conteo de productos activos por negocio
        this.productRepository
          .createQueryBuilder('p')
          .select('p.business_id', 'business_id')
          .addSelect('COUNT(p.id)', 'count')
          .where('p.business_id IN (:...businessIds)', { businessIds })
          .andWhere('p.is_active = true')
          .groupBy('p.business_id')
          .getRawMany(),
        // 4. Proveedores ordenados por cantidad de productos activos
        this.providerRepository
          .createQueryBuilder('pr')
          .leftJoin(Product, 'p', 'p.provider_id = pr.id AND p.is_active = true')
          .select('pr.business_id', 'business_id')
          .addSelect('pr.id', 'provider_id')
          .addSelect('pr.name', 'provider_name')
          .addSelect('COUNT(p.id)', 'products_count')
          .where('pr.business_id IN (:...businessIds)', { businessIds })
          .andWhere('pr.is_active = true')
          .groupBy('pr.business_id')
          .addGroupBy('pr.id')
          .addGroupBy('pr.name')
          .orderBy('pr.business_id', 'ASC')
          .addOrderBy('COUNT(p.id)', 'DESC')
          .addOrderBy('pr.name', 'ASC')
          .getRawMany(),
        // 5. Traducciones
        this.translationService.attachTranslations('businesses', businesses),
      ]);

      const collabMap = new Map(myCollaborations.map((c) => [c.business_id, c]));
      const collabCountsMap = new Map(
        collabCountsRaw.map((r) => [r.business_id, parseInt(r.count, 10) || 0]),
      );
      const productsCountMap = new Map(
        productsCountsRaw.map((r) => [r.business_id, parseInt(r.count, 10) || 0]),
      );

      const providersByBusinessMap = new Map<
        string,
        Array<{ id: string; name: string; products_count: number }>
      >();

      for (const row of providersWithCountsRaw) {
        const bId = row.business_id;
        if (!providersByBusinessMap.has(bId)) {
          providersByBusinessMap.set(bId, []);
        }
        providersByBusinessMap.get(bId)!.push({
          id: String(row.provider_id),
          name: String(row.provider_name),
          products_count: parseInt(row.products_count, 10) || 0,
        });
      }

      return (translated as Business[]).map((b) => {
        const isOwner = String(b.owner_id) === String(userId);
        const myCollab = collabMap.get(b.id);
        const collabsCount = collabCountsMap.get(b.id) ?? 0;
        const allProviders = providersByBusinessMap.get(b.id) ?? [];

        b.user_role = isOwner || isSuper ? 'owner' : 'collaborator';
        b.user_position = isOwner ? 'Owner' : (isSuper ? 'Super Admin' : (myCollab?.position ?? null));
        b.user_action_ids = isOwner || isSuper ? [] : (myCollab?.action_ids ?? []);
        b.collaborators_count = collabsCount;
        b.has_collaborators = collabsCount > 0;
        b.products_count = productsCountMap.get(b.id) ?? 0;
        b.top_providers = allProviders.slice(0, 3);
        b.has_more_providers = allProviders.length > 3;
        b.total_providers_count = allProviders.length;

        return b;
      });
    };

    if (all) {
      const rawData = await qb.getMany();
      const data = await formatBusinesses(rawData);
      return {
        data,
        meta: {
          page: 1,
          limit: data.length,
          total_items: data.length,
          total_pages: 1,
        },
      };
    }

    const [rawData, total_items] = await qb
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    const data = await formatBusinesses(rawData);
    const total_pages = Math.ceil(total_items / limit);

    return {
      data,
      meta: {
        page,
        limit,
        total_items,
        total_pages,
      },
    };
  }

  async findOne(id: string, userId?: string, includeSummary = true): Promise<Business> {
    // NodiaAI scoped readers reuse a transaction manager. Serialize membership
    // observations with owner/collaborator writes before reading their state.
    if (this.businessRepository.manager?.queryRunner?.isTransactionActive)
      await this.businessRepository.manager.query('SELECT id FROM businesses WHERE id=$1 FOR SHARE', [id]);
    const rawBusiness = await this.businessRepository.findOne({
      where: { id },
      relations: includeSummary ? { owner: true } : undefined,
    });
    if (!rawBusiness) {
      throw new NotFoundException(`Business with ID "${id}" not found`);
    }

    const business = (await this.translationService.attachTranslationsToOne(
      'businesses',
      rawBusiness,
    )) as Business;

    if (userId) {
      const isOwner = String(business.owner_id) === String(userId);
      const collaborator = await this.collaboratorRepository.findOne({
        where: {
          business_id: id,
          user_id: String(userId),
          is_active: true,
        },
      });
      const isSuper = await this.isSuperAdmin(userId);

      if (!isOwner && !collaborator && !isSuper) {
        throw new ForbiddenException('You do not have access to this business');
      }

      business.user_role = isOwner || isSuper ? 'owner' : 'collaborator';
      business.user_position = isOwner ? 'Owner' : (isSuper ? 'Super Admin' : (collaborator?.position ?? null));
      business.user_action_ids = isOwner || isSuper ? [] : (collaborator?.action_ids ?? []);
    }

    if (!includeSummary) return business;

    const [productsCount, collaborators, allProviders] = await Promise.all([
      this.productRepository.count({
        where: { business_id: id, is_active: true },
      }),
      this.collaboratorRepository.find({
        where: { business_id: id, is_active: true },
        relations: { user: true },
        order: { created_at: 'DESC' },
      }),
      this.providerRepository
        .createQueryBuilder('pr')
        .leftJoin(Product, 'p', 'p.provider_id = pr.id AND p.is_active = true')
        .select('pr.id', 'provider_id')
        .addSelect('pr.name', 'provider_name')
        .addSelect('COUNT(p.id)', 'products_count')
        .where('pr.business_id = :id', { id })
        .andWhere('pr.is_active = true')
        .groupBy('pr.id')
        .addGroupBy('pr.name')
        .orderBy('COUNT(p.id)', 'DESC')
        .addOrderBy('pr.name', 'ASC')
        .getRawMany(),
    ]);

    business.products_count = productsCount;
    business.collaborators = collaborators;
    business.collaborators_count = collaborators.length;
    business.has_collaborators = collaborators.length > 0;
    business.top_providers = allProviders.slice(0, 3).map((pr) => ({
      id: String(pr.provider_id),
      name: String(pr.provider_name),
      products_count: parseInt(pr.products_count, 10) || 0,
    }));
    business.has_more_providers = allProviders.length > 3;
    business.total_providers_count = allProviders.length;

    return business;
  }

  async create(userId: string, createBusinessDto: CreateBusinessDto, manager?: EntityManager): Promise<Business> {
    if (!manager) {
      const saved = await this.businessRepository.manager.transaction((tx) => this.create(userId, createBusinessDto, tx));
      return this.findOne(saved.id, userId);
    }
    await lockAuthority(manager);
    const repository = manager.getRepository(Business);
    const { translates, ...businessData } = createBusinessDto;
    const business = repository.create({
      ...businessData,
      has_description: translates?.some(({ key, es, en }) =>
        ['description', 'comment'].includes(key) && Boolean(es?.trim() || en?.trim()),
      ) ?? false,
      owner_id: String(userId),
    });
    const saved = await repository.save(business);
    if (translates?.length) await this.translationService.updateTranslations('businesses', saved.id, translates, manager);
    return this.translationService.attachTranslationsToOne('businesses', saved, manager);
  }

  async update(id: string, userId: string, updateBusinessDto: UpdateBusinessDto, manager?: EntityManager): Promise<Business> {
    if (!manager) {
      await this.businessRepository.manager.transaction((tx) => this.update(id, userId, updateBusinessDto, tx));
      return this.findOne(id, userId);
    }
    await lockAuthority(manager);
    const repository = manager.getRepository(Business);
    const business = await repository.findOne({ where: { id }, lock: { mode: 'pessimistic_write' } });
    if (!business) throw new NotFoundException(`Business with ID "${id}" not found`);
    if (String(business.owner_id) !== String(userId) && !(await this.isSuperAdmin(userId, manager)))
      throw new ForbiddenException('Only the business owner can update business details');
    const { translates, ...rest } = updateBusinessDto;
    Object.assign(business, rest);
    if (translates !== undefined) {
      business.has_description = translates.some(({ key, es, en }) =>
        ['description', 'comment'].includes(key) && Boolean(es?.trim() || en?.trim()),
      );
      await this.translationService.updateTranslations('businesses', id, translates, manager);
    }
    await repository.save(business);
    return this.translationService.attachTranslationsToOne('businesses', business, manager);
  }

  async assignCollaborators(businessId: string, userId: string, dto: AssignCollaboratorsDto, manager?: EntityManager): Promise<BusinessCollaborator[]> {
    if (!manager) return this.businessRepository.manager.transaction((tx) => this.assignCollaborators(businessId, userId, dto, tx));
    await lockAuthority(manager);
    const business = await manager.getRepository(Business).findOne({ where: { id: businessId }, lock: { mode: 'pessimistic_write' } });
    if (!business) throw new NotFoundException(`Business with ID "${businessId}" not found`);
    if (String(business.owner_id) !== String(userId) && !(await this.isSuperAdmin(userId, manager)))
      throw new ForbiddenException('Only the business owner can manage collaborators');
    const collaborators = manager.getRepository(BusinessCollaborator);
    const allActionIds = Array.from(new Set(dto.users.flatMap((u) => u.action_ids ?? [])));
    if (allActionIds.length) {
      const existingActions = await manager.getRepository(BusinessAction).find({ where: { id: In(allActionIds), is_active: true } });
      const existingIds = new Set(existingActions.map((a) => String(a.id)));
      const invalidIds = allActionIds.filter((id) => !existingIds.has(String(id)));
      if (invalidIds.length) throw new BadRequestException(`Invalid or inactive business action IDs: ${invalidIds.join(', ')}`);
    }
    for (const item of dto.users) {
      const existing = await collaborators.findOne({ where: { business_id: businessId, user_id: String(item.user_id) } });
      if (!item.action_ids?.length) {
        if (existing) { existing.is_active = false; existing.action_ids = []; await collaborators.save(existing); }
      } else if (existing) {
        existing.position = item.position !== undefined ? item.position : existing.position;
        existing.action_ids = item.action_ids; existing.is_active = true;
        await collaborators.save(existing);
      } else {
        await collaborators.save(collaborators.create({ business_id: businessId, user_id: String(item.user_id), position: item.position ?? null, action_ids: item.action_ids, is_active: true }));
      }
    }
    return collaborators.find({ where: { business_id: businessId, is_active: true }, relations: { user: true } });
  }
}
